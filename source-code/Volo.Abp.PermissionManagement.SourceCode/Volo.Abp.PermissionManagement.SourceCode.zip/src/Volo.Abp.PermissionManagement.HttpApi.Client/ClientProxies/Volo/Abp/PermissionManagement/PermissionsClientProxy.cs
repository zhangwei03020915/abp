// This file is part of PermissionsClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Abp.PermissionManagement;

public partial class PermissionsClientProxy
{
}
