﻿using Volo.Abp.Localization;

namespace Volo.Abp.FeatureManagement.Localization;

[LocalizationResourceName("AbpFeatureManagement")]
public class AbpFeatureManagementResource
{

}
