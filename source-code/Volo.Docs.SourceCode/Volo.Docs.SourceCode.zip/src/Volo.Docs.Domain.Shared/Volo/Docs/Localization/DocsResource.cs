﻿using Volo.Abp.Localization;

namespace Volo.Docs.Localization
{
    [LocalizationResourceName("Docs")]
    public class DocsResource
    {

    }
}
