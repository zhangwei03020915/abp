// This file is part of DocumentsAdminClientProxy, you can customize it here
// ReSharper disable once CheckNamespace
namespace Volo.Docs.Admin;

public partial class DocumentsAdminClientProxy
{
}
