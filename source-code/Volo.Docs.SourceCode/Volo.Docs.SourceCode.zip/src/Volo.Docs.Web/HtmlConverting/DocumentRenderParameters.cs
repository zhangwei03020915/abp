﻿using System.Collections.Generic;

namespace Volo.Docs.HtmlConverting
{
    public class DocumentRenderParameters : Dictionary<string,string>
    {
    }
}