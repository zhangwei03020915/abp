﻿namespace Volo.Docs.EntityFrameworkCore
{
    public class ProjectRepository_Tests : ProjectRepository_Tests<DocsEntityFrameworkCoreTestModule>
    {

    }
}
