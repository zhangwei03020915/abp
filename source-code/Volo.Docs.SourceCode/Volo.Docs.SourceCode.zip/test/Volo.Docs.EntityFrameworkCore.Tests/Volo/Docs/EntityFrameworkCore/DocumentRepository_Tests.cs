﻿namespace Volo.Docs.EntityFrameworkCore
{
    public class DocumentRepository_Tests : DocumentRepository_Tests<DocsEntityFrameworkCoreTestModule>
    {
    }
}