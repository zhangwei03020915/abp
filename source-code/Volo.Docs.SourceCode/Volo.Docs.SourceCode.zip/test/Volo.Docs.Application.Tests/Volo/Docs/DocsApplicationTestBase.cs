﻿namespace Volo.Docs
{
    public class DocsApplicationTestBase : DocsTestBase<DocsApplicationTestModule>
    {

    }
}
