﻿namespace Volo.Abp.VirtualFileExplorer.Web.Navigation;

public class VirtualFileExplorerMenuNames
{
    public const string GroupName = "AbpVirualFileExplorer";

    public const string Index = GroupName + ".Index";
}
