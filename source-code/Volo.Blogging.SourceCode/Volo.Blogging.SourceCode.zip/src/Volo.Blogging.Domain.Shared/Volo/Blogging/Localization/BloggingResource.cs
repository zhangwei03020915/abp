﻿using Volo.Abp.Localization;

namespace Volo.Blogging.Localization
{
    [LocalizationResourceName("Blogging")]
    public class BloggingResource
    {
    }
}
