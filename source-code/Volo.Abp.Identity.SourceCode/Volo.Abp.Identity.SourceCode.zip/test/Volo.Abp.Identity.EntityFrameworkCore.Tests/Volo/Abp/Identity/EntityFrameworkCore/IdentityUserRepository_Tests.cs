﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentityUserRepository_Tests : IdentityUserRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{

}
