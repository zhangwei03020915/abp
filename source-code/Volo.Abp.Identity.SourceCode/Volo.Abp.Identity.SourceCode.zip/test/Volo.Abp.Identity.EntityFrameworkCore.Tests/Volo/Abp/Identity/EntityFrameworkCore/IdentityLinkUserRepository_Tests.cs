﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentityLinkUserRepository_Tests : IdentityLinkUserRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{

}
