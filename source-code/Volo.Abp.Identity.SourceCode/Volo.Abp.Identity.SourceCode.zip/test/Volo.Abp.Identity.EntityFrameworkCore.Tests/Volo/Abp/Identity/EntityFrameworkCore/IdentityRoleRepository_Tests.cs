﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentityRoleRepository_Tests : IdentityRoleRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{

}
