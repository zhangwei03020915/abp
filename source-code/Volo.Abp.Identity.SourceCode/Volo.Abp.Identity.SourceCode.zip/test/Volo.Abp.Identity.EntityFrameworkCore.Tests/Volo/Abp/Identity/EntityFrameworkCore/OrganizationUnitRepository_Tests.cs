﻿namespace Volo.Abp.Identity.EntityFrameworkCore;

public class OrganizationUnitRepository_Tests : OrganizationUnitRepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{
}
