namespace Volo.Abp.Identity.EntityFrameworkCore;

public class IdentityUserDelegationepository_Tests : IdentityUserDelegationepository_Tests<AbpIdentityEntityFrameworkCoreTestModule>
{
    
}