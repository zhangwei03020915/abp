export const enum eIdentityPolicyNames {
  IdentityManagement = 'AbpIdentity.Roles || AbpIdentity.Users',
  Roles = 'AbpIdentity.Roles',
  Users = 'AbpIdentity.Users',
}
