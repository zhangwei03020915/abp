﻿namespace Volo.Abp.Identity;

public enum IdentityClaimValueType
{
    String,
    Int,
    Boolean,
    DateTime
}
