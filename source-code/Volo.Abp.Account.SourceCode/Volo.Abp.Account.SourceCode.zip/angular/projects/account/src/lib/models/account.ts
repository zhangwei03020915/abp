/* eslint-disable @typescript-eslint/no-empty-interface */

export namespace Account {
  export interface TenantBoxComponentInputs {}
  export interface TenantBoxComponentOutputs {}
  export interface PersonalSettingsComponentInputs {}
  export interface PersonalSettingsComponentOutputs {}
  export interface ChangePasswordComponentInputs {}
  export interface ChangePasswordComponentOutputs {}
}
