import { InjectionToken } from '@angular/core';

export const RE_LOGIN_CONFIRMATION_TOKEN = new InjectionToken<boolean>(
  'RE_LOGIN_CONFIRMATION_TOKEN',
);
