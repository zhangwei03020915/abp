import * as Areas from './areas';
export { Areas };
