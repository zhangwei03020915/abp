﻿namespace Volo.Abp.IdentityServer;

public class IdentityResourceRepository_Tests : IdentityResourceRepository_Tests<AbpIdentityServerTestEntityFrameworkCoreModule>
{

}
