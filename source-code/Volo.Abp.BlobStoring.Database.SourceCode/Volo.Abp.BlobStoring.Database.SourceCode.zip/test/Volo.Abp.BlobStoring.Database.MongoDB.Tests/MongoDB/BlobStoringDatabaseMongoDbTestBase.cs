﻿namespace Volo.Abp.BlobStoring.Database.MongoDB;

public abstract class BlobStoringDatabaseMongoDbTestBase : BlobStoringDatabaseTestBase<BlobStoringDatabaseMongoDbTestModule>
{

}
