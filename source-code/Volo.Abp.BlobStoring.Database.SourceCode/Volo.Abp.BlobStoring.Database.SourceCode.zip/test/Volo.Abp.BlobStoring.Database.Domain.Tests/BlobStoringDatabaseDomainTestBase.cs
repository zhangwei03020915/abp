﻿namespace Volo.Abp.BlobStoring.Database;

/* Inherit from this class for your domain layer tests.
 * See SampleManager_Tests for example.
 */
public abstract class BlobStoringDatabaseDomainTestBase : BlobStoringDatabaseTestBase<BlobStoringDatabaseDomainTestModule>
{

}
