﻿namespace Volo.Abp.OpenIddict;

public class OpenIddictSecurityLogIdentityConsts
{
    public static string OpenIddict { get; set; } = "OpenIddict";
}