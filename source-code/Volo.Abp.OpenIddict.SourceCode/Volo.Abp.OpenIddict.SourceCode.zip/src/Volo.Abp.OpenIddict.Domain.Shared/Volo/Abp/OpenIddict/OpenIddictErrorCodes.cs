﻿namespace Volo.Abp.OpenIddict;

public static class OpenIddictErrorCodes
{
    //Add your business exception error codes here...
}
