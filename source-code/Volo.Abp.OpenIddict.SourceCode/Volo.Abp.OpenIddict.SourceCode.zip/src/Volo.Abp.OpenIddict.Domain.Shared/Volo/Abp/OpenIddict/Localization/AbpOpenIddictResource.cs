﻿using Volo.Abp.Localization;

namespace Volo.Abp.OpenIddict.Localization;

[LocalizationResourceName("AbpOpenIddict")]
public class AbpOpenIddictResource
{

}
