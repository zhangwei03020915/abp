﻿namespace Volo.Abp.OpenIddict.Scopes;

public class OpenIddictScopeConsts
{
    public static int NameMaxLength { get; set; } = 200;
}
