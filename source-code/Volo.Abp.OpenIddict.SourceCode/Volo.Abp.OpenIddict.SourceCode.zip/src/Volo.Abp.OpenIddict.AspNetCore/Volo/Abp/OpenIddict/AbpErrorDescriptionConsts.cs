namespace Volo.Abp.OpenIddict;

public static class AbpErrorDescriptionConsts
{
    public const string RequiresTwoFactor = "RequiresTwoFactor";

    public const string RequiresConfirmUser = "RequiresConfirmUser";
}
