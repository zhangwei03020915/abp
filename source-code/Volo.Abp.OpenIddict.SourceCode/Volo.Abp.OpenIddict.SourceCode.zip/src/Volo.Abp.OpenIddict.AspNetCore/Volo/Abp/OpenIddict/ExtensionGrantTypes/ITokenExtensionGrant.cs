﻿namespace Volo.Abp.OpenIddict.ExtensionGrantTypes;

public interface ITokenExtensionGrant : IExtensionGrant
{

}
