﻿namespace Volo.CmsKit.Admin.Web.Pages.CmsKit.BlogPosts;

public class IndexModel : CmsKitAdminPageModel
{

}
