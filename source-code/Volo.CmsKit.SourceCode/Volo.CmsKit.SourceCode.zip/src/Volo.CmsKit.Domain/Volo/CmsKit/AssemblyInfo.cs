﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("Volo.CmsKit.Domain.Tests", AllInternalsVisible = true)] 
[assembly: InternalsVisibleTo("Volo.CmsKit.TestBase", AllInternalsVisible = true)] 