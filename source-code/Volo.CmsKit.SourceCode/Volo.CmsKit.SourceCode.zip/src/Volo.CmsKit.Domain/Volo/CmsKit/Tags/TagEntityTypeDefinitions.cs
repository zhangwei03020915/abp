﻿using System.Collections.Generic;

namespace Volo.CmsKit.Tags;

public class TagEntityTypeDefinitions : List<TagEntityTypeDefiniton>
{
}
