﻿namespace Volo.CmsKit.MediaDescriptors;

public interface IMediaDescriptorDefinitionStore : IEntityTypeDefinitionStore<MediaDescriptorDefinition>
{

}
