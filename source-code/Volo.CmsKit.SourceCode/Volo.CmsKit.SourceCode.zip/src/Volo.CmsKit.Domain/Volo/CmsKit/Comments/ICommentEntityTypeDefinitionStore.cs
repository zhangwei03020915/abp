﻿namespace Volo.CmsKit.Comments;

public interface ICommentEntityTypeDefinitionStore : IEntityTypeDefinitionStore<CommentEntityTypeDefinition>
{

}
