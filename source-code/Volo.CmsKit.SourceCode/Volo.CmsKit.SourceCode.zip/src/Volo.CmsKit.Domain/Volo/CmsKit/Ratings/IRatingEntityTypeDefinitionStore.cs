﻿using Volo.CmsKit.Ratings;

namespace Volo.CmsKit.Ratings;

public interface IRatingEntityTypeDefinitionStore : IEntityTypeDefinitionStore<RatingEntityTypeDefinition>
{

}
