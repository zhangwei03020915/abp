﻿namespace Volo.CmsKit.Web;

public static class CmsBlogsWebConsts
{
    public static string BlogsRoutePrefix { get; set; } = "blogs";
}
