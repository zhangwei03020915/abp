﻿using Volo.CmsKit.Web.Icons;

namespace Volo.CmsKit.Web.MarkedItems;

public class MarkedItemIconDictionary : LocalizableIconDictionaryBase
{
}
