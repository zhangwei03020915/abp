﻿namespace Volo.CmsKit.Public.Web.Security.Captcha;

public enum EncoderTypes
{
    Jpeg,
    Png,
}