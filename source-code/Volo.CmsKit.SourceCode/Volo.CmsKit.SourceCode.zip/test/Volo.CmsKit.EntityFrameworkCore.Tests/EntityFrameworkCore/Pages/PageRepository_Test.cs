﻿using Volo.CmsKit.Pages;

namespace Volo.CmsKit.EntityFrameworkCore.Pages;

public class PageRepository_Test : PageRepository_Test<CmsKitEntityFrameworkCoreTestModule>
{

}
