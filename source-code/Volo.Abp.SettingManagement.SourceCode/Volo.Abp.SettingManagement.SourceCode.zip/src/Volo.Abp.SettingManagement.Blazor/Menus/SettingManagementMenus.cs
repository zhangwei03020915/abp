﻿namespace Volo.Abp.SettingManagement.Blazor.Menus;

public class SettingManagementMenus
{
    public const string GroupName = "SettingManagement";
}
